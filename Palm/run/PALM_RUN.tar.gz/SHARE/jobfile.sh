#!/bin/bash
#SBATCH --job-name=Store2D
#SBATCH --account=Project_2001816
#SBATCH --partition=fmi
#SBATCH --time=12:00:00
#SBATCH --ntasks=800
#SBATCH -N 20-20
#SBATCH --mem-per-cpu=4400

export MPICH_MPIIO_STATS=1
E8="=8"
export MPICH_MPIIO_HINTS="*DATA_**:striping_factor"$E8   # switch on disc striping to get better
                                                          # I/O-performance for the netCDF I/O

module load netcdf-fortran/4.4.4  hdf5/1.10.4-mpi  parallel-netcdf 

RUNDIR=/fmi/scratch/project_2001816/palm_cases/VIRAL-SPREAD/Store2C

cd $RUNDIR
 
srun -n 800  ./palm   

rm DEBUG_* 
rm PLOT2D_* 
rm NO_COMB*
